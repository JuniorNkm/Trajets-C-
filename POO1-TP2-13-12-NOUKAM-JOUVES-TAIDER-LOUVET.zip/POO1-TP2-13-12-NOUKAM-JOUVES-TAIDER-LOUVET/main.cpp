#include<iostream>
#include<stdlib.h>
#include<cstring>
#include"Catalogue.h"
#define n 6
using namespace std;

//Veuillez à bien lire les recommandations pour l'entréé des données(surtout pour les choix).

int main()
{
	char Menu[n][50]={"Catalogue des lieux","Catalogue des trajets","Ajout d'un Trajet","Recherche simple d'un itinéraire","Recherche avancée d'un itinéraire","Quitter"};	
	
	Catalogue *C=new Catalogue();
	char choix,* depart=new char[15],* destination=new char[15];
	int quitter=0;
	do
	{
		cout<<"\n\n"<<endl;
		for(int i=0;i<n;i++)cout<<i+1<<"- "<<Menu[i]<<endl;
		cout<<"\n\t\t\tVotre choix :  ";
		cin>>choix;
		cout<<endl;
		
		switch(choix)
		{
			case '1': C->AfficheLieu();
				break;
			case '2': C->Affichecatalogue();
				break;
			case '3': C->AjoutTrajet();
				break;
			case '4': cout<<"\nVous devez entrer des lieux présents dans le catalogue des lieux."<<endl;
				cout<<"\nEntrer le point de départ : ";
				cin>>depart;
				cout<<endl;
				cout<<"\nEntrer le point d'arrivée : " ;
				cin>>destination;
				cout<<endl;
				C->RechercheSimple(depart,destination);
				break;
			case '5': cout<<"\nVous devez entrer des lieux présents dans le catalogue des lieux."<<endl;
				cout<<"\nEntrer le point de départ : ";
				cin>>depart;
				cout<<endl;
				cout<<"\nEntrer le point d'arrivée : " ;
				cin>>destination;
				cout<<endl;
				C->RechercheAvancee(depart,destination);
				break;
			case '6': quitter=1;
				break;
			default:cout<<"\n\nChoix non défini."<<endl;
				break;
		}
	//system("pause");
	}while(quitter==0);
	delete[] depart;
	delete[] destination;
	delete C;
	cout<<"\n\n\t😉️Ciao😉️\n\n"<<endl;
	return 0;
}
