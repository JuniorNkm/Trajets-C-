#include"TrajetC.h"
#include"TrajetS.h"
using namespace std;

void TrajetC::make()
{
	int i=0;
	char v='1';
	char * depart=new char[15],*dest=new char[15],*transp=new char[15];
	cout<<"\nEntrer le point de départ"<<  " : ";
	cin>>depart;
	cout<<endl;
	
	Depart=new char[strlen(depart)+1];
	strcpy(Depart,depart);
	Tc=new ListeCH;
	
	while(v=='1')
	{
			
			cout<<"\nEntrer le point d'arrivée n°"<< i+1<< " : ";
			cin>>dest;
			cout<<endl;
			cout<<"\nEntrer le Moyen de transport n°"<< i+1<< " : ";
			cin>>transp;
			cout<<endl;
			Trajet * t=new TrajetS(depart,dest,transp);
			element * elt=new element(t);
			strcpy(depart,dest);
			Tc->insert(elt);
			cout<<"\nInsérer un nouveau tronçon? 1-OUI 2-NON\n\t\t\tVotre choix : ";
			cin>>v;
			nbmaillons++;
			i++;
			
	}
	Dest=new char[strlen(depart)+1];
	strcpy(Dest,depart);
	delete []depart;
	delete []transp;
	delete []dest;
}
ListeCH* TrajetC:: get_Liste()
{
	return Tc;
}
		    
void TrajetC::Affiche()const
{
	Tc->Affiche();
}

TrajetC::TrajetC():Trajet(),Tc(nullptr)
{
	nbmaillons=1;
	#ifdef MAP
		cout << "Appel au constructeur de TrajetC" << endl;
	#endif
}
TrajetC:: ~TrajetC()
		    {
		    	delete Tc;
		    	#ifdef MAP
			    cout << "Appel au destructeur de TrajetC" << endl;
			#endif
		    }
