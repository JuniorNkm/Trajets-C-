#if ! defined ( TRAJET_H )
#define TRAJET_H

//--------------------------------------------------- Interfaces utilisées
#include<iostream>
#include<cstring>
using namespace std;

// Rôle de la classe <Trajet>
//Définition d'un trajet basique i.e. départ-arrivéé
//L'attribut nbmaillons ne sert qu'à différencier les descendants trajet simple et trajet composé ( vaut 1 par défaut et >1 pour un trajet composé )

//------------------------------------------------------------------------

	class Trajet
	{

		
		public:
			//----------------------------------------------------- Méthodes publiques
			virtual void Affiche()const;
			// Mode d’emploi :
		    	// Affiche le trajet
	  	    	// Contrat : aucun
		        int get_nbmaillons();
		        // Mode d’emploi :
		    	// Retourne le nombre de maillons du trajet
	  	    	// Contrat : aucun
		        char * get_Depart();
		        // Mode d’emploi :
		    	// Retourne le pointeur Depart
	  	    	// Contrat : aucun
	  	    	char * get_Dest();
	  	    	// Mode d’emploi :
		    	//  Retourne le pointeur Dest
	  	    	// Contrat : aucun
		        //-------------------------------------------- Constructeurs - destructeur
		        Trajet(const char *undepart, const char *unedestination);
		        Trajet();
		        virtual ~Trajet();

		//------------------------------------------------------------------ PRIVE
		protected:
		char *Depart;//pointeur vers la chaine de caractere du point de départ
		char *Dest;//pointeur vers la chaine de caractere du point d'arrivée
		int nbmaillons;//nombre de maillons du trajet

	};
	
#endif // TRAJET_H
