#if ! defined ( ELEMENT_H )
#define ELEMENT_H

//--------------------------------------------------- Interfaces utilisées
#include<iostream>
#include"Trajet.h"
using namespace std;

// Rôle de la classe <element>
//Maillon d'une liste chainée de trajets, stocke un pointeur vers un trajet et un autre vers le prochain élément de la liste
//Définition d'un maillon

//------------------------------------------------------------------------
	class element
	{
		
		public:
		//----------------------------------------------------- Méthodes publiques
		    
		    void Affiche()const;
		    // Mode d’emploi :
		    // Affiche le trajet pointé
	  	    // Contrat : aucun
		    element* get_next();
		    // Mode d’emploi :
		    // Retourne le pointeur next
	  	    // Contrat : aucun
		    Trajet* get_trajet();
		    // Mode d’emploi :
		    // Retourne le pointeur trajet
	  	    // Contrat : aucun
		    void alter_next(element* e);
		    // Mode d’emploi :
		    // Affecte e à next
	  	    // Contrat : aucun
		//-------------------------------------------- Constructeurs - destructeur
		    element(Trajet * T);
		    element();
		    virtual ~element();

		//------------------------------------------------------------------ PRIVE
		protected:
		Trajet * trajet;//pointeur vers le trajet du maillon
		element *next;//pointeur vers le prochain maillon
		
	};

#endif // ELEMENT_H
