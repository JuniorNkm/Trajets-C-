#include"TrajetS.h"
using namespace std;


TrajetS::TrajetS (const char *undépart,const char *unedestination,const char *unmoytrans):Trajet(undépart,unedestination)
		    {
		    	MoyT=new char[strlen(unmoytrans)+1];
		    	strcpy(MoyT,unmoytrans);
		    	nbmaillons=1;
		    	#ifdef MAP
			    cout << "Appel au constructeur de TrajetS" << endl;
			#endif
		    }
TrajetS::~TrajetS ()
		    {
		    	delete[] MoyT;
		    	#ifdef MAP
			    cout << "Appel au destructeur de TrajetS" << endl;
			#endif
		    }
void TrajetS::Affiche()const
	{
	   	cout<< Depart <<" à "<< Dest <<" en "<<MoyT;
        }
