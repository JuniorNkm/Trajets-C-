#if ! defined ( CATALOGUE_H )
#define CATALOGUE_H

//--------------------------------------------------- Interfaces utilisées
#include<iostream>
#include"ListeCH.h"
#include"TrajetC.h"
#include"TrajetS.h"

// Rôle de la classe <Catalogue>
//Réunir un ensemble de Trajets afin de pouvoir déterminer des différents itinéraires de voyages entre 2 destinations 
//Définition d'un catalogue

//------------------------------------------------------------------------

	class Catalogue
	{
		public:
		//----------------------------------------------------- Méthodes publiques
		    void AjoutTrajet();
		    // Mode d’emploi :
		    // Ajoute un trajet dans le catalogue
	  	    // Contrat : aucun
		    void Affichecatalogue()const;
		    // Mode d’emploi :
		    // Affiche tous les trajets du le catalogue
	  	    // Contrat : aucun
		    void RechercheSimple(const char *depart,const char *dest)const;
		    // Mode d’emploi :
		    // Recherche des trajets parmi les trajets prédéfinis et affiche ceux permettant d'aller de depart(ville de départ) à dest(ville d'arrivéé)
	  	    // Contrat : aucun
		    void RechercheAvancee(const char *depart,const char *dest)const;
		    // Mode d’emploi :
		    // Recherche des trajets et des combinaisons de trajets parmi les trajets prédéfinis et affiche ceux permettant d'aller de depart(ville de départ) à dest(ville d'arrivéé)
	  	    // Contrat : aucun
		    void AjoutTLieu(const char *lieu);
		    // Mode d’emploi :
		    // Ajoute les lieux entrés lors de l'ajout d'un trajet, dans le catalogue des lieux (attribut Lieu) s'ils n'ont pas encore été enregistrés)
	  	    // Contrat : On ne peut avoir plus de 1000 destinations dans le catalogue
		    int  RechercheLieu(const char *lieu)const;
		    // Mode d’emploi :
		    // Recherche "lieu" parmi les lieux enregistrés et retourne 0 si présent et 1 sinon 
	  	    // Contrat : aucun
		    void AfficheLieu()const;
		    // Mode d’emploi :
		    // Affiche les lieux enregistrés
	  	    // Contrat : aucun
		    //-------------------------------------------- Constructeurs - destructeur
		    Catalogue();
		    virtual ~Catalogue();

		protected:
		//----------------------------------------------------- Attributs protégés
		ListeCH *Cat;//Liste chainée de trajet définis
		int nbTrajet;//nombre de trajets enregistrés
		char Lieu[1000][15];//ensemble des lieux mentionnés dans les trajets
		int nbLieu;//nombre de lieux effectivement enregistrés
	};
	
#endif // CATALOGUE_H
