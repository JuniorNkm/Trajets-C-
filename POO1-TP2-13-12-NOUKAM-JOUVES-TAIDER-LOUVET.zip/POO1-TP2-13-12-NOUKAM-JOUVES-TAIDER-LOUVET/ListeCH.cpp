#include"ListeCH.h"
using namespace std;


void ListeCH::insert(element * e)
{
	if(first==nullptr)
	{
		first=e;
		last=e;
	}
	else
	{
		last->alter_next(e);
		last=e;
	}
	nb++;
}

void ListeCH::Affiche()const
{
	element *e=first;
	if(nb==0)cout <<"\nAucun Trajet dans : { }." <<endl;
	else
	{
		
		do
		{
			e->Affiche();
			e=e->get_next();
			if(e!=nullptr)cout<<" - ";
		}while(e!=nullptr);
	}
}

element* ListeCH::get_first()
{
	return first;
}

element* ListeCH::get_last()
{
	return last;
}

int  ListeCH::get_nb()
{
	return nb;
}

ListeCH::ListeCH():first(nullptr),last(nullptr),nb(0)
{
	#ifdef MAP
	    cout << "Appel au constructeur de ListeCH" << endl;
	#endif
}

ListeCH::~ListeCH()
{
	element *p=first,*pre=first;
    	while(p!=last)
    	{
    		pre=p;
    		p=p->get_next();
    		delete pre;
    	}
    	delete p;
    	#ifdef MAP
	    cout << "Appel au destructeur de ListeCH" << endl;
	#endif
}

