#include"Trajet.h"
using namespace std;


void Trajet::Affiche()const		   
{
   cout<<"De "<<this->Depart<<" à "<<this->Dest<<endl;
}
int Trajet::get_nbmaillons()
{
	return nbmaillons;
}
char* Trajet::get_Depart()
{
	return Depart;
}
char* Trajet::get_Dest()
{
	return Dest;
}	    

Trajet::Trajet(const char *undepart, const char *unedestination)
		    {
		    	Depart=new char[strlen(undepart)+1];
		    	Dest=new char[strlen(unedestination)+1];
		    	strcpy(Depart,undepart);
		    	strcpy(Dest,unedestination);
		    	nbmaillons=1;
		    	#ifdef MAP
			    cout << "Appel au constructeur de Trajet" << endl;
			#endif
		    }
Trajet::~Trajet()
		        {
		    	 	if(Depart!=nullptr)delete[] Depart;
		    		if(Dest!=nullptr)delete[] Dest;
		    		#ifdef MAP
			    		cout << "Appel au destructeur de Trajet" << endl;
				#endif
		    	}
		    	
Trajet::Trajet() {
	Depart = nullptr;
	Dest = nullptr;
	#ifdef MAP
		 cout << "Appel au constructeur de Trajet" << endl;
	#endif
}
