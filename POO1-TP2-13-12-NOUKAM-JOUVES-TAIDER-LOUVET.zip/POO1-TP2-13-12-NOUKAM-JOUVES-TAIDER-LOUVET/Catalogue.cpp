#include<iostream>
#include<cstring>
#include"Catalogue.h"
using namespace std;


//------------------------------------------------------------------------
/**/

void Catalogue::AjoutTrajet()
{
	int choix;
	if(Cat==nullptr) Cat= new ListeCH;
	cout<<"\n1-Trajet Simple\n2-Trajet compose\n\n\tVotre choix: ";
	cin>>choix;
	cout<<endl;
	if(choix==1)
	{
		char * depart=new char[15],*dest=new char[15],*transp=new char[15];
		cout<<"\nEntrer le point de départ"<<  " : ";
		cin>>depart;
		cout<<endl;
		if(RechercheLieu(depart)==0)AjoutTLieu(depart);
		cout<<"\nEntrer le point d'arrivée : " ;
		cin>>dest;
		cout<<endl;
		if(RechercheLieu(dest)==0)AjoutTLieu(dest);
		cout<<"\nEntrer le Moyen de transport : ";
		cin>>transp;
		cout<<endl;
		Trajet * t=new TrajetS(depart,dest,transp);
		element * elt=new element(t);
		Cat->insert(elt);
		delete []depart;
		delete []transp;
		delete []dest;
	}
	else
	{
		TrajetC * t=new TrajetC();
		t->make();
		element * elt=new element(t);
		element *p=t->get_Liste()->get_first();
		Cat->insert(elt);
	    	while(p!=nullptr)
	    	{
	    		if(RechercheLieu(p->get_trajet()->get_Depart())==0)AjoutTLieu(p->get_trajet()->get_Depart());
	    		if(RechercheLieu(p->get_trajet()->get_Dest())==0)AjoutTLieu(p->get_trajet()->get_Dest());
	    		p=p->get_next();
	    	}
		
	}
	nbTrajet+=1;
	cout<<"\n\nTrajet ajouté \n\t\tNombres de trajets enregistrés :"<<nbTrajet<<endl;
}   

void Catalogue::Affichecatalogue()const
{
	if(nbTrajet==0)cout <<"\nAucun Trajet dans le catalogue : { }." <<endl;
	else
	 {
	 	int nbts=1,nbtc=1,i=1;
	 	element *e=Cat->get_first();
	 	do
		{
			if(e->get_trajet()->get_nbmaillons()==1)cout<<"\n"<<i<<" : "<<"TS"<<nbts++<<" =  De ";
		 	else cout<<"\n"<<i<<" : "<<"TC"<<nbtc++<<" =  De ";
		 	e->Affiche();
		 	e=e->get_next();
		 	i++;
		}while(e!=nullptr);
		cout<<endl;
	 }
}

void Catalogue::RechercheSimple(const char *depart,const char *dest)const
{
	if(nbTrajet==0)cout<<"\nAucun trajet enregistré dans le cataloque"<<endl;
	else
	{
		if(RechercheLieu(depart)==0 && RechercheLieu(dest)==0)cout<<"\nCes lieux ne sont pas dans le catalogue des lieux."<<endl;
		else if(RechercheLieu(depart)==0)cout<<"\nCe point de depart n'est pas dans le catalogue des lieux."<<endl;
		     else if(RechercheLieu(dest)==0)cout<<"\nCe point d'arrivee n'est pas dans le catalogue des lieux."<<endl;
		     	  else{
		     	  		int a=0,v=0;
					cout<<"\n"<<endl;
					element * elt=Cat->get_first();
					while(elt!=nullptr)
					{
						if(strcmp(elt->get_trajet()->get_Depart(),depart)==0 && strcmp(elt->get_trajet()->get_Dest(),dest)==0)
						{
							cout<<"T"<<++a<<" = "<<" De ";
							elt->get_trajet()->Affiche();
							cout<<endl;
							v=1;
						}
						elt=elt->get_next();
					}
					if(v==0)cout<<"\nAucun trajet direct trouvé dans le cataloque."<<endl;
				}
	}
}

void Catalogue::RechercheAvancee(const char *depart,const char *dest)const
{
	if(nbTrajet==0)cout<<"\nAucun trajet enregistré dans le cataloque"<<endl;
	else
	{
		if(RechercheLieu(depart)==0 && RechercheLieu(dest)==0)cout<<"\nCes lieux ne sont pas dans le catalogue des lieux."<<endl;
		else if(RechercheLieu(depart)==0)cout<<"\nCe point de depart n'est pas dans le catalogue des lieux."<<endl;
		     else if(RechercheLieu(dest)==0)cout<<"\nCe point d'arrivee n'est pas dans le catalogue des lieux."<<endl;
		     	  else{
					element *elt,*e=Cat->get_first();
					int i=1,nb=0,t=1,*tab=new int[nbTrajet],v=0;
					char *det=new char[15];
					int a=0;
					while(e!=nullptr)
					{	
						elt=e;
						i=t;
						nb=0;
						strcpy(det,dest);
						if(strcmp(e->get_trajet()->get_Dest(),det)==0)
						{
							while(elt!=nullptr && nb<nbTrajet)
							{
								if(strcmp(elt->get_trajet()->get_Dest(),det)==0)
								{
									if(strcmp(elt->get_trajet()->get_Depart(),depart)==0)
									{
										tab[nb++]=i;
										cout<<"T"<<++a<<" = "<<" De ";
										for(int j=nb-1;j>=0;j--)
										{
											int k=1;
											element *p=Cat->get_first();
											while(k!=tab[j])
											{
												p=p->get_next();
												k++;
											}
											p->get_trajet()->Affiche();
											if(nb>1 && j!=0)cout<<" puis de ";
										}
										cout<<endl;
										v=1;
										break;
									}
									else
									{	
										strcpy(det,elt->get_trajet()->get_Depart());
										tab[nb++]=i;
										i=1;
										elt=Cat->get_first();
									}
								}
								else 
								{
									i++;
									elt=elt->get_next();
								}
							}
						}
						e=e->get_next();
						t++;		
					}
					delete[] det;
					delete[] tab;
					if(v==0)cout<<"\nAucun itineraire trouve dans le cataloque."<<endl;
				}
	}
}

void Catalogue::AjoutTLieu(const char *lieu)
{
	if(RechercheLieu(lieu)==0)
	{
		if(nbLieu<100)
		{
			strcpy(Lieu[nbLieu],lieu);
			nbLieu++;
;		}
	}
}

int  Catalogue::RechercheLieu(const char *lieu)const
{
	int est_present=0;
	for(int i=0;i<nbLieu;i++)
	{
		if(strcmp(lieu,Lieu[i])==0)
		 {
		 	est_present=1;
		 }
	}
	return est_present;
}
void Catalogue::AfficheLieu()const
{
	if(nbLieu==0)cout <<"\nAucun lieu dans le catalogue : { }." <<endl;
	else{
		cout <<"\n{ " <<Lieu[0];

		for(int i=1;i<nbLieu;i++)
		{
			cout << " , " <<Lieu[i];
		}
		cout << " }\n " <<endl;
	   }
}

Catalogue::Catalogue():Cat(nullptr),nbTrajet(0)
{
	#ifdef MAP
	    cout << "Appel au constructeur de catalogue" << endl;
	#endif
}

Catalogue::~Catalogue()
	    {
	    	delete Cat;
	    	#ifdef MAP
	    		cout << "Appel au destructeur de catalogue" << endl;
		#endif
	    }
