#if ! defined ( TRAJETS_H )
#define TRAJETS_H

//--------------------------------------------------- Interfaces utilisées
#include<iostream>
#include"Trajet.h"
using namespace std;
// Rôle de la classe <TrajetS>
//Définition d'un trajet Simple basique i.e. départ-arrivéé-moyen de transport

//------------------------------------------------------------------------

	class TrajetS: public Trajet 
	{

		
		public:
		//----------------------------------------------------- Méthodes publiques
		    virtual void Affiche()const;
		    // Mode d’emploi :
		    // Affiche le trajet
	  	    // Contrat : aucun
	  	    
		//-------------------------------------------- Constructeurs - destructeur
		    TrajetS (const char *undépart,const char *unedestination,const char *unmoytrans);
		    virtual ~TrajetS ();


		//------------------------------------------------------------------ PRIVE
		protected:
		char *MoyT;//pointeur vers le moyen de transport

	};
	
#endif // TRAJETS_H
