#if ! defined ( LISTE_H )
#define LISTE_H

//--------------------------------------------------- Interfaces utilisées
#include<iostream>
#include"element.h"

// Rôle de la classe <ListeCH>
//Permet d'obtenir une liste chainée de trajets
//Définition d'un trajet basique i.e. départ-arrivéé

//------------------------------------------------------------------------

	class ListeCH
	{
		
		public:
		//----------------------------------------------------- Méthodes publiques
		    
		    void insert(element * e);
		    // Mode d’emploi :
		    // Insert l'element e en queue de la liste chainée
	  	    // Contrat : aucun
		    void Affiche()const;
		    // Mode d’emploi :
		    // Affiche les trajets insérés dans la liste
	  	    // Contrat : aucun
		    element* get_first();
		    // Mode d’emploi :
		    // Retourne le pointeur first 
	  	    // Contrat : aucun
		    element* get_last();
		    // Mode d’emploi :
		    // Retourne le pointeur last 
	  	    // Contrat : aucun
		    int get_nb();
		    // Mode d’emploi :
		    // Retourne l'entier nb
	  	    // Contrat : aucun
	  	    
		    //-------------------------------------------- Constructeurs - destructeur
		    ListeCH();
		    virtual ~ListeCH();

		
		//------------------------------------------------------------------ PRIVE
		protected:
		element *first;//pointeur vers la tete de la liste
		element *last;//pointeur vers la queue de la liste
		int nb;//Nombre de trajets enregistrés dans la liste
		
	};
	

#endif // LISTE_H
