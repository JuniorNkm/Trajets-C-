#if ! defined ( TRAJETC_H )
#define TRAJETC_H

//--------------------------------------------------- Interfaces utilisées
#include<iostream>
#include"ListeCH.h"

// Rôle de la classe <TrajetC>
//Définition d'un trajet composé
//L'attribut Tc permet de stocker les trajets qui compose un trajet composé de manière ordonnée

//------------------------------------------------------------------------

	class TrajetC: public Trajet
	{
		
		public:
		//----------------------------------------------------- Méthodes publiques
		    
		    void make();
		    // Mode d’emploi :
		    // Initialise le trajet compoé
	  	    // Contrat : aucun
		    ListeCH * get_Liste();
		    // Mode d’emploi :
		    // Retourne le pointeur Tc
	  	    // Contrat : aucun
		    virtual void Affiche()const;
		    // Mode d’emploi :
		    // Affiche la liste Tc et donc le trajet composé
	  	    // Contrat : aucun
		    //-------------------------------------------- Constructeurs - destructeur
		    TrajetC();
		    virtual ~TrajetC();

		//------------------------------------------------------------------ PRIVE
		protected:
		ListeCH *Tc;//permet de stocker les trajets qui compose un trajet composé de manière ordonnée
	};

#endif // TRAJETC_H

